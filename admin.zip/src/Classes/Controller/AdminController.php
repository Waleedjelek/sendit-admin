<?php

namespace App\Classes\Controller;

class AdminController extends BaseController
{
}
