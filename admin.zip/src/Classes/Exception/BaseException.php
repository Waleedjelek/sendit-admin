<?php

namespace App\Classes\Exception;

class BaseException extends \Exception
{
}
