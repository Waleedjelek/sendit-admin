<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/admin/auditlog' => [[['_route' => 'app_audit_index', '_controller' => 'App\\Controller\\Admin\\AuditController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/company' => [[['_route' => 'app_company_index', '_controller' => 'App\\Controller\\Admin\\CompanyController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/company/new' => [[['_route' => 'app_company_new', '_controller' => 'App\\Controller\\Admin\\CompanyController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/country' => [[['_route' => 'app_country_index', '_controller' => 'App\\Controller\\Admin\\CountryController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/' => [[['_route' => 'app_home', '_controller' => 'App\\Controller\\Admin\\DashboardController::home'], null, null, null, false, false, null]],
        '/admin' => [[['_route' => 'app_admin_home', '_controller' => 'App\\Controller\\Admin\\DashboardController::home'], null, null, null, true, false, null]],
        '/admin/dashboard' => [[['_route' => 'app_dashboard', '_controller' => 'App\\Controller\\Admin\\DashboardController::index'], null, null, null, false, false, null]],
        '/admin/locale' => [[['_route' => 'app_locale_index', '_controller' => 'App\\Controller\\Admin\\LocaleController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/locale/new' => [[['_route' => 'app_locale_new', '_controller' => 'App\\Controller\\Admin\\LocaleController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/orders' => [[['_route' => 'app_order_index', '_controller' => 'App\\Controller\\Admin\\OrderController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/package-types' => [[['_route' => 'app_package_type_index', '_controller' => 'App\\Controller\\Admin\\PackageTypeController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/package-types/new' => [[['_route' => 'app_package_type_new', '_controller' => 'App\\Controller\\Admin\\PackageTypeController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/price-search' => [[['_route' => 'app_price_search', '_controller' => 'App\\Controller\\Admin\\PriceSearchController::search'], null, ['GET' => 0], null, true, false, null]],
        '/admin/price-search/data' => [[['_route' => 'app_price_search_data', '_controller' => 'App\\Controller\\Admin\\PriceSearchController::searchData'], null, ['POST' => 0], null, false, false, null]],
        '/admin/quotes' => [[['_route' => 'app_quote_index', '_controller' => 'App\\Controller\\Admin\\QuoteController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\Admin\\SecurityController::login'], null, null, null, false, false, null]],
        '/reset-password' => [[['_route' => 'app_reset_password', '_controller' => 'App\\Controller\\Admin\\SecurityController::resetPassword'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\Admin\\SecurityController::logout'], null, null, null, false, false, null]],
        '/admin/transactions' => [[['_route' => 'app_transaction_index', '_controller' => 'App\\Controller\\Admin\\TransactionController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/user' => [[['_route' => 'app_user_index', '_controller' => 'App\\Controller\\Admin\\UserController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/admin/user/profile' => [[['_route' => 'app_user_profile', '_controller' => 'App\\Controller\\Admin\\UserController::profile'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/user/password' => [[['_route' => 'app_user_password', '_controller' => 'App\\Controller\\Admin\\UserController::password'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/user/new' => [[['_route' => 'app_user_new', '_controller' => 'App\\Controller\\Admin\\UserController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/api/v1/auth/register' => [[['_route' => 'app_api_auth_register', '_controller' => 'App\\Controller\\Api\\AuthController::register'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/auth/login' => [[['_route' => 'app_api_auth_login', '_controller' => 'App\\Controller\\Api\\AuthController::login'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/auth/reset-password' => [[['_route' => 'app_api_auth_resetpassword', '_controller' => 'App\\Controller\\Api\\AuthController::resetPassword'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/auth/refresh' => [[['_route' => 'app_api_auth_autologin', '_controller' => 'App\\Controller\\Api\\AuthController::autoLogin'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/auth/logout' => [[['_route' => 'app_api_auth_logout', '_controller' => 'App\\Controller\\Api\\AuthController::logout'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/general/getQuote' => [[['_route' => 'app_api_general_getquote', '_controller' => 'App\\Controller\\Api\\GeneralController::getQuote'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/general/createQuote' => [[['_route' => 'app_api_general_createquote', '_controller' => 'App\\Controller\\Api\\GeneralController::createQuote'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/general/countries' => [[['_route' => 'app_api_general_countries', '_controller' => 'App\\Controller\\Api\\GeneralController::countries'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/general/tracking' => [[['_route' => 'app_api_general_tracking', '_controller' => 'App\\Controller\\Api\\GeneralController::tracking'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/general/locales' => [[['_route' => 'app_api_general_locales', '_controller' => 'App\\Controller\\Api\\GeneralController::locales'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/general/states' => [[['_route' => 'app_api_general_states', '_controller' => 'App\\Controller\\Api\\GeneralController::states'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/general/packageTypes' => [[['_route' => 'app_api_general_packagetypes', '_controller' => 'App\\Controller\\Api\\GeneralController::packageTypes'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/general/quoteData' => [[['_route' => 'app_api_general_quotedata', '_controller' => 'App\\Controller\\Api\\GeneralController::quoteData'], null, ['GET' => 0], null, false, false, null]],
        '/api/v1/address/list' => [[['_route' => 'app_api_useraddress_list', '_controller' => 'App\\Controller\\Api\\UserAddressController::list'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/address/add' => [[['_route' => 'app_api_useraddress_add', '_controller' => 'App\\Controller\\Api\\UserAddressController::add'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/address/edit' => [[['_route' => 'app_api_useraddress_edit', '_controller' => 'App\\Controller\\Api\\UserAddressController::edit'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/address/delete' => [[['_route' => 'app_api_useraddress_delete', '_controller' => 'App\\Controller\\Api\\UserAddressController::delete'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/user/updateProfile' => [[['_route' => 'app_api_user_updateprofile', '_controller' => 'App\\Controller\\Api\\UserController::updateProfile'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/user/changePassword' => [[['_route' => 'app_api_user_changepassword', '_controller' => 'App\\Controller\\Api\\UserController::changePassword'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/user/activateEmail' => [[['_route' => 'app_api_user_activateemail', '_controller' => 'App\\Controller\\Api\\UserController::activateEmail'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/user/updatePicture' => [[['_route' => 'app_api_user_updatepicture', '_controller' => 'App\\Controller\\Api\\UserController::updatePicture'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/orders/list' => [[['_route' => 'app_api_userorders_list', '_controller' => 'App\\Controller\\Api\\UserOrdersController::list'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/orders/get' => [[['_route' => 'app_api_userorders_getinfo', '_controller' => 'App\\Controller\\Api\\UserOrdersController::getInfo'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/orders/add' => [[['_route' => 'app_api_userorders_add', '_controller' => 'App\\Controller\\Api\\UserOrdersController::add'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/transactions/list' => [[['_route' => 'app_api_usertransaction_list', '_controller' => 'App\\Controller\\Api\\UserTransactionController::list'], null, ['POST' => 0], null, false, false, null]],
        '/api/v1/transactions/get' => [[['_route' => 'app_api_usertransaction_getinfo', '_controller' => 'App\\Controller\\Api\\UserTransactionController::getInfo'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|wdt/([^/]++)(*:24)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:69)'
                            .'|router(*:82)'
                            .'|exception(?'
                                .'|(*:101)'
                                .'|\\.css(*:114)'
                            .')'
                        .')'
                        .'|(*:124)'
                    .')'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:159)'
                .')'
                .'|/admin/(?'
                    .'|co(?'
                        .'|mpany(?'
                            .'|/([^/]++)(?'
                                .'|(*:203)'
                                .'|/e(?'
                                    .'|dit(*:219)'
                                    .'|xport(*:232)'
                                .')'
                                .'|(*:241)'
                            .')'
                            .'|\\-zone/([^/]++)(?'
                                .'|(*:268)'
                                .'|/(?'
                                    .'|new(*:283)'
                                    .'|show/([^/]++)(*:304)'
                                    .'|([^/]++)(?'
                                        .'|/edit(*:328)'
                                        .'|(*:336)'
                                    .')'
                                .')'
                            .')'
                        .')'
                        .'|untry/([^/]++)/edit(*:367)'
                    .')'
                    .'|t(?'
                        .'|est\\-email/order/([^/]++)(*:405)'
                        .'|ransactions/([^/]++)(?'
                            .'|(*:436)'
                        .')'
                    .')'
                    .'|locale/([^/]++)(?'
                        .'|/edit(*:469)'
                        .'|(*:477)'
                    .')'
                    .'|orders/(?'
                        .'|([^/]++)(*:504)'
                        .'|track\\-(?'
                            .'|add/([^/]++)(*:534)'
                            .'|show/([^/]++)(*:555)'
                        .')'
                        .'|print/([^/]++)(*:578)'
                        .'|delete/([^/]++)(*:601)'
                    .')'
                    .'|package\\-types/([^/]++)(?'
                        .'|(*:636)'
                        .'|/(?'
                            .'|edit(*:652)'
                            .'|delete(*:666)'
                        .')'
                    .')'
                    .'|quotes/(?'
                        .'|([^/]++)(*:694)'
                        .'|delete/([^/]++)(*:717)'
                    .')'
                    .'|user/([^/]++)(?'
                        .'|(*:742)'
                        .'|/(?'
                            .'|edit(*:758)'
                            .'|reset\\-password(*:781)'
                        .')'
                        .'|(*:790)'
                    .')'
                    .'|zone\\-price/([^/]++)(?'
                        .'|(*:822)'
                        .'|/(?'
                            .'|new(*:837)'
                            .'|([^/]++)/edit(*:858)'
                            .'|import(*:872)'
                        .')'
                    .')'
                .')'
                .'|/payment/(?'
                    .'|order/([^/]++)/do\\-payment(*:921)'
                    .'|transaction/([^/]++)/(?'
                        .'|success(*:960)'
                        .'|failed(*:974)'
                        .'|cancelled(*:991)'
                        .'|update(*:1005)'
                    .')'
                .')'
                .'|/reset\\-(?'
                    .'|validate/([^/]++)/([^/]++)(*:1053)'
                    .'|pass\\-val/([^/]++)/([^/]++)(*:1089)'
                .')'
                .'|/email\\-activate/([^/]++)/([^/]++)(*:1133)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        24 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        69 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        82 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        101 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        114 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        124 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        159 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        203 => [[['_route' => 'app_company_show', '_controller' => 'App\\Controller\\Admin\\CompanyController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        219 => [[['_route' => 'app_company_edit', '_controller' => 'App\\Controller\\Admin\\CompanyController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        232 => [[['_route' => 'app_company_export', '_controller' => 'App\\Controller\\Admin\\CompanyController::export'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        241 => [[['_route' => 'app_company_delete', '_controller' => 'App\\Controller\\Admin\\CompanyController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        268 => [[['_route' => 'app_zone_index', '_controller' => 'App\\Controller\\Admin\\ZoneController::index'], ['companyId'], ['POST' => 0], null, true, true, null]],
        283 => [[['_route' => 'app_zone_new', '_controller' => 'App\\Controller\\Admin\\ZoneController::new'], ['companyId'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        304 => [[['_route' => 'app_zone_show', '_controller' => 'App\\Controller\\Admin\\ZoneController::show'], ['companyId', 'id'], ['GET' => 0], null, false, true, null]],
        328 => [[['_route' => 'app_zone_edit', '_controller' => 'App\\Controller\\Admin\\ZoneController::edit'], ['companyId', 'id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        336 => [[['_route' => 'app_zone_delete', '_controller' => 'App\\Controller\\Admin\\ZoneController::delete'], ['companyId', 'id'], ['POST' => 0], null, false, true, null]],
        367 => [[['_route' => 'app_country_edit', '_controller' => 'App\\Controller\\Admin\\CountryController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        405 => [[['_route' => 'app_test_email_order', '_controller' => 'App\\Controller\\Admin\\DashboardController::sample'], ['id'], null, null, false, true, null]],
        436 => [
            [['_route' => 'app_transaction_show', '_controller' => 'App\\Controller\\Admin\\TransactionController::show'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_transaction_delete', '_controller' => 'App\\Controller\\Admin\\TransactionController::delete'], ['id'], ['POST' => 0], null, false, true, null],
        ],
        469 => [[['_route' => 'app_locale_edit', '_controller' => 'App\\Controller\\Admin\\LocaleController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        477 => [[['_route' => 'app_locale_delete', '_controller' => 'App\\Controller\\Admin\\LocaleController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        504 => [[['_route' => 'app_order_show', '_controller' => 'App\\Controller\\Admin\\OrderController::show'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        534 => [[['_route' => 'app_order_add_tracking', '_controller' => 'App\\Controller\\Admin\\OrderController::addTrackingCode'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        555 => [[['_route' => 'app_order_show_tracking', '_controller' => 'App\\Controller\\Admin\\OrderController::showTracking'], ['id'], ['GET' => 0], null, false, true, null]],
        578 => [[['_route' => 'app_order_show_print', '_controller' => 'App\\Controller\\Admin\\OrderController::showPrint'], ['id'], ['GET' => 0], null, false, true, null]],
        601 => [[['_route' => 'app_order_delete', '_controller' => 'App\\Controller\\Admin\\OrderController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        636 => [[['_route' => 'app_package_type_show', '_controller' => 'App\\Controller\\Admin\\PackageTypeController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        652 => [[['_route' => 'app_package_type_edit', '_controller' => 'App\\Controller\\Admin\\PackageTypeController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        666 => [[['_route' => 'app_package_type_delete', '_controller' => 'App\\Controller\\Admin\\PackageTypeController::delete'], ['id'], ['POST' => 0], null, false, false, null]],
        694 => [[['_route' => 'app_quote_show', '_controller' => 'App\\Controller\\Admin\\QuoteController::show'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null]],
        717 => [[['_route' => 'app_quote_delete', '_controller' => 'App\\Controller\\Admin\\QuoteController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        742 => [[['_route' => 'app_user_show', '_controller' => 'App\\Controller\\Admin\\UserController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        758 => [[['_route' => 'app_user_edit', '_controller' => 'App\\Controller\\Admin\\UserController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        781 => [[['_route' => 'app_user_pass_reset', '_controller' => 'App\\Controller\\Admin\\UserController::resetPassword'], ['id'], ['POST' => 0], null, false, false, null]],
        790 => [[['_route' => 'app_user_delete', '_controller' => 'App\\Controller\\Admin\\UserController::delete'], ['id'], ['POST' => 0], null, false, true, null]],
        822 => [[['_route' => 'app_zone_price_index', '_controller' => 'App\\Controller\\Admin\\ZonePriceController::index'], ['zoneId'], ['POST' => 0], null, true, true, null]],
        837 => [[['_route' => 'app_zone_price_new', '_controller' => 'App\\Controller\\Admin\\ZonePriceController::new'], ['zoneId'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        858 => [[['_route' => 'app_zone_price_edit', '_controller' => 'App\\Controller\\Admin\\ZonePriceController::edit'], ['zoneId', 'id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        872 => [[['_route' => 'app_zone_price_import', '_controller' => 'App\\Controller\\Admin\\ZonePriceController::import'], ['zoneId'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        921 => [[['_route' => 'app_payment_redirect', '_controller' => 'App\\Controller\\Admin\\PaymentController::paymentRedirect'], ['id'], ['GET' => 0], null, false, false, null]],
        960 => [[['_route' => 'app_payment_success', '_controller' => 'App\\Controller\\Admin\\PaymentController::transactionSuccess'], ['id'], ['GET' => 0], null, false, false, null]],
        974 => [[['_route' => 'app_payment_failed', '_controller' => 'App\\Controller\\Admin\\PaymentController::transactionFailed'], ['id'], ['GET' => 0], null, false, false, null]],
        991 => [[['_route' => 'app_payment_cancelled', '_controller' => 'App\\Controller\\Admin\\PaymentController::transactionCancelled'], ['id'], ['GET' => 0], null, false, false, null]],
        1005 => [[['_route' => 'app_payment_update', '_controller' => 'App\\Controller\\Admin\\PaymentController::transactionUpdate'], ['id'], ['POST' => 0], null, false, false, null]],
        1053 => [[['_route' => 'app_reset_validate', '_controller' => 'App\\Controller\\Admin\\SecurityController::validateResetPassword'], ['id', 'code'], null, null, true, true, null]],
        1089 => [[['_route' => 'app_api_reset_validate', '_controller' => 'App\\Controller\\Admin\\SecurityController::apiValidateResetPassword'], ['id', 'code'], null, null, true, true, null]],
        1133 => [
            [['_route' => 'app_api_email_activate', '_controller' => 'App\\Controller\\Admin\\SecurityController::apiEmailActivate'], ['id', 'code'], null, null, true, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
